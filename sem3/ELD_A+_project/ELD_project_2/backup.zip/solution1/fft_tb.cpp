#include "fft.h"

int main(){

	complex_type FFT_output[N];

    complex_type FFT_input[N] = {
        complex_type(11.0, 23.0),
        complex_type(32.0, 10.0),
        complex_type(91.0, 94.0),
        complex_type(15.0, 69.0),
        complex_type(47.0, 96.0),
        complex_type(44.0, 12.0),
        complex_type(96.0, 17.0),
        complex_type(49.0, 58.0)
    };

    fft_8point(FFT_input, FFT_output);

    for(int i = 0; i < N; i++){
    	if(cabs(FFT_output[i]) - cabs(expected_output[i]) > TOLERANCE){
    		return FAILIURE;
    	}
    }

    return SUCCESS;
}

float cabs(complex_type z) {
    return std::sqrt(z.real() * z.real() + z.imag() * z.imag());
}
